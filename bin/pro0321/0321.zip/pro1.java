package pro0321;
//20211219 ����
import java.util.Scanner;

public class pro1 {

	public static void main(String[] args) {

		int n1, n2, res;

		Scanner sc = new Scanner(System.in);
		System.out.print("�� ���� �� �Է� : ");
		n1 = sc.nextInt();
		n2 = sc.nextInt();
		res = n1 + n2;
		System.out.println("res : " + res);

	}

}
